import Form from "../Form";

function QuizForm() {
  return (
    <section className="">
      <div className="container">
        <div className=" quiz">
          <Form />
        </div>
      </div>
    </section>
  );
}

export default QuizForm;
