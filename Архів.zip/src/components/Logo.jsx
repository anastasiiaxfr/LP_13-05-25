function Logo() {
  return <div>Logo</div>;
}

export default Logo;
